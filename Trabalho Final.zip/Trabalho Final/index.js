function mostrarNome(){
    let p= document.createElement("p");
    let inputName= document.querySelector("input");
    let textoNovo= document.createTextNode(`Olá ${inputName.value} você está no meu coração <3`)
    p.appendChild(textoNovo);
    document.body.appendChild(p);
}
let botao= document.querySelector("button");
botao.addEventListener("click",mostrarNome);
botao.onClick= mostrarNome;

var n1= document.querySelector('#n1')
var n2= document.querySelector('#n2')
var resultado= document.querySelector('span')
function somar() {
    resultado.innerHTML= parseInt(n1.value) + parseInt(n2.value)
}
function subtrair() {
    resultado.innerHTML= parseInt(n1.value) - parseInt(n2.value)
}
function multiplicar() {
    resultado.innerHTML= parseInt(n1.value) * parseInt(n2.value)
}
function dividir() {
    resultado.innerHTML= parseInt(n1.value) / parseInt(n2.value)
}

